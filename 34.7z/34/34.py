# Даны два файла в каждом из которых находится 
# запись многочлена. Сформировать файл содержащий сумму многочленов.

import math
def getkof(mystr):
    kof1=0
    kof2=0
    kof3=0

    kof3=int(mystr.split(' ')[-1])
    if mystr.split(' ')[-2] == '-':
        kof3*=-1
    raz=mystr.split(' ')
    kof2=int(raz[2].split('x')[0])
    if mystr.split(' ')[1] == '-':
        kof2*=-1
        kof1=int(mystr.split('x')[0])
    return kof1, kof2, kof3
data1=open(r'D:\python\1\34\num1.txt','r' )
data2=open(r'D:\python\1\34\num2.txt','r' ) 

a=getkof(data1.read())
b=getkof(data2.read())

data1.close()
data2.close()

summ=[]
for i in range(3):
    summ.append(a[i]+b[i])
print(summ)
data3 = open(r'D:\python\1\34\num3.txt','w')
for i in range (1,3):
    if summ[i]>0:
        summ[i]='+' + str(summ[i])
data3.writelines(f'{summ[0]}x**2 {summ[1]} {summ[2]}')

